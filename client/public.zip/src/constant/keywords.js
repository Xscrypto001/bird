const keywords = [
  {
    id: 2,
    content: ["technology"],
    userName: "@NazmulIslam007",
    description:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt nesciunt sequi quae odit nihil, tenetur placeat eum commodi excepturi repellat.",
    time: "2h",
    img: "",
    video: "/assets/video1.mp4",
    thumbnail: "/assets/1.jpg",
    comments: 2,
    views: "125k",
    react: 10,
    retweet: 0,
    share: 3,
  },
  {
    id: 3,
    name: "Zahid Hasan",
    userName: "@Zahidhasan007",
    description:
      "Good morning Everyone. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt nesciunt sequi quae odit nihil, tenetur placeat eum commodi excepturi repellat. Good morning Everyone. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt nesciunt sequi quae odit nihil, tenetur placeat eum commodi excepturi repellat.",
    time: "2h",
    comments: 2,
    react: 10,
    retweet: 5,
    share: 3,
  },

  {
    id: 4,
    name: "Nazmul Islam",
    userName: "@NazmulIslam007",
    description:
      "Good morning Everyone. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt nesciunt sequi quae odit nihil, tenetur placeat eum commodi excepturi repellat.",
    time: "2h",
    img: "",
    views: "125k",
    video: "/assets/video.mp4",
    thumbnail: "/assets/2.jpg",
    comments: 2,
    react: 10,
    retweet: 0,
    share: 3,
  },
];

export default keywords;
