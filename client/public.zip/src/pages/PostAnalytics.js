import React from "react";
import PostAnalytic from "../components/PostAnalytic";

export default function PostAnalytics() {
  return (
    <div className="max-w-[700px] mx-auto">
      <PostAnalytic />
    </div>
  );
}
