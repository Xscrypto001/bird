import React from "react";
import EditProfile from "../components/Profile/EditProfile";

export default function EditProfilePage() {
  return (
    <div className="max-w-[600px] mx-auto">
      <EditProfile />
    </div>
  );
}
