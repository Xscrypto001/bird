import React from "react";

export default function SteamManager() {
  return <div>SteamManager</div>;
}
